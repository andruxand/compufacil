<?php

define('HOST','192.168.41.8');
define('USER','usr_aprender');
define('PASS','2jCzCNpzv622A5qe');
define('DBNAME','cms_inscripcion');

?>