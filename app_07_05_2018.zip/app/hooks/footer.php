
<div id="fullpage-loader" style="display: none">
    <div class="loader-content">
        <i id="loader-icon" class="oi oi-loop-circular fa-spin"></i>
        <div id="loader-error" style="display: none">
            Error<br/>
                <i class="oi oi-shield"></i> Por favor contacte a soporte
        </div>
    </div>
    <div class="text-right">
        <button type="button" class="fullpage-loader-close btn btn-link tip" aria-label="Cerrar"
                title="Cerrar" data-placement="left">
            <span aria-hidden="true"><i class="oi oi-x"></i></span>
        </button>
    </div>
</div>
</body>
</html>